class DemoMonitor:
    @staticmethod
    def run():
        print("\n🎬 Running Demo Monitor...")
        print("Simulating soil and water monitoring...")
        for i in range(1, 6):
            print(f"Cycle {i}: Monitoring sensors...")
