from setuptools import setup

setup(
    name="bioshield",
    version="1.0.0",
    packages=[],  # سنضيفها لاحقاً
    install_requires=["numpy", "pandas"],
)
