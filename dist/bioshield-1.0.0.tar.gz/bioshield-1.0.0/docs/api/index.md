---
layout: default
title: API Reference
nav_order: 3
has_children: true
---
# API Reference

Complete API documentation for BioShield modules and functions.
