---
layout: default
title: Getting Started
nav_order: 2
has_children: true
---
# Getting Started

Welcome to BioShield! This guide will help you install and configure the system.
